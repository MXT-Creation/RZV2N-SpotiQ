# If the library is currently getting classified as -dev
INSANE_SKIP:${PN} += "dev-so"

# Ensure the runtime package contains the .so
FILES:${PN} += "${libdir}/libdrp_api.so"

# Help shlibs scanner treat unversioned .so as a shared lib
SOLIBS = ".so"
SOLIBSDEV = ".so"
